#Requires -module CISDSC
#Requires -RunAsAdministrator

<#
    .DESCRIPTION
    Applies CIS Level one benchmarks for Microsoft Windows Server 2016 Member Server build 1607 with no exclusions.
    Exclusion documentation can be found in the docs folder of this module.
#>

Configuration Microsoft_Windows_Server_2016_Member_Server_1607_CIS_L1
{
    Import-DSCResource -ModuleName 'CISDSC' -Name 'CIS_Microsoft_Windows_Server_2016_Member_Server_Release_1607'

    node 'localhost'
    {
        CIS_Microsoft_Windows_Server_2016_Member_Server_Release_1607 'CIS Benchmarks'
        {
            cis2315AccountsRenameadministratoraccount = 'CISAdmin'
            cis2316AccountsRenameguestaccount = 'CISGuest'
            cis2375LegalNoticeCaption = 'Legal Notice'
            cis2374LegalNoticeText = @"
This is a super secure device that we don't want bad people using.
I'm even making sure to put this as a literal string so that I can cleanly
use multiple lines to tell you how super secure it is.
"@
        }
    }
}

Microsoft_Windows_Server_2016_Member_Server_1607_CIS_L1
$nEnvelopeSize = Get-Item -Path 'WSMan:\localhost\MaxEnvelopeSizeKb'
Set-Item -Path 'WSMan:\localhost\MaxEnvelopeSizeKb' -Value 8192 

### Comment out the Start-DSCConfig line, put these lines at the bottom of C:\Windows\System32\WindowsPowerShell\v1.0\Modules\CISDSC\examples\CIS_Microsoft_Windows_Server_2016_Member_Server_Release_1607.ps1
$Report = Test-DscConfiguration -Path '.\Microsoft_Windows_Server_2016_Member_Server_1607_CIS_L1' -Verbose
$Report.ResourcesInDesiredState | Select-Object -Property 'ResourceId','InDesiredState' | Export-CSV -Path 'C:\Users\VC763HM\OneDrive - EY\Desktop\ResourcesInDesiredState.csv'
$Report.ResourcesNotInDesiredState | Select-Object -Property 'ResourceId','InDesiredState' | Export-CSV -Path 'C:\Users\VC763HM\OneDrive - EY\Desktop\NotInDesiredState.csv'
### END OF TEST BENCHMARKING

### TO REVERT ENVELOPE SIZE
Set-Item -Path 'WSMan:\localhost\MaxEnvelopeSizeKb' -Value $nEnvelopeSize.Value 