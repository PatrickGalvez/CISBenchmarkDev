﻿## This script exports the configuration of a server based on CIS Benchmarks ##

$supportedVersions = @(
    "Server 2016",
    "Server 2019"
)

## Set error action preference
$ErrorActionPreference = 'Stop'

Write-Host "Start of Execution"
Write-Host "Timestamp: $(Get-Date -Format "hh:mm:ss tt")"

$version = (Get-WmiObject win32_operatingsystem).name
if (-not(($supportedVersions | %{$version.contains($_)}) -contains $true)) {
    write-host "This script is not compatible with the current Server OS" -ForegroundColor Red
    return $false
}

$directory = $PSScriptRoot

## Initial Cleanup
Write-Host "Initiating Cleanup"
If (Test-Path "$directory\Modules") {
    Write-Host "Deleting Modules" -ForegroundColor Gray
    Remove-Item -Path "$directory\Modules" -Recurse -Force
}

If (Test-Path "$directory\Output") {
    Write-Host "Deleting Output" -ForegroundColor Gray
    Remove-Item -Path "$directory\Output" -Recurse -Force
}

If (Test-Path "$directory\Output.zip") {
    Write-Host "Deleting Output.zip" -ForegroundColor Gray
    Remove-Item -Path "$directory\Output.zip" -Recurse -Force
}


## Unblock Module Files
If (-not(Test-Path "$directory\Modules")) {
    Write-Host "Unzipping Modules"
    Get-ChildItem -Path "$directory\Modules.zip" -Recurse | Unblock-File
    Expand-Archive -LiteralPath "$directory\Modules.zip" -DestinationPath "$directory\Modules"
}

## Copy CISDSC Modules to Powershell
Write-Host "Transferring Required Modules"
If (-not(Test-Path 'C:\Program Files\WindowsPowerShell\Modules\AuditPolicyDsc')) {
    Copy-Item -Path "$directory\Modules\AuditPolicyDsc" `
              -Destination 'C:\Program Files\WindowsPowerShell\Modules\AuditPolicyDsc' -Recurse
} 

If (-not(Test-Path 'C:\Program Files\WindowsPowerShell\Modules\CISDSC')) {
    Copy-Item -Path "$directory\Modules\CISDSC" `
              -Destination 'C:\Program Files\WindowsPowerShell\Modules\CISDSC' -Recurse
}

If (-not(Test-Path 'C:\Program Files\WindowsPowerShell\Modules\SecurityPolicyDsc')) {
    Copy-Item -Path "$directory\Modules\SecurityPolicyDsc" `
              -Destination 'C:\Program Files\WindowsPowerShell\Modules\SecurityPolicyDsc' -Recurse
}

## Import CISDSC Module
If ((-not((Get-DscResource | %{$_.Name.Contains("CIS")}) -contains $true))) {
    Import-Module CISDSC -Force -Verbose
}

## Get Envelope Size
$envelopeSize = Get-Item -Path 'WSMan:\localhost\MaxEnvelopeSizeKb'
Write-Host "MaxEnvelopeSize: $envelopeSize.value"

## Set Envelope Size to 8192
Set-Item -Path 'WSMan:\localhost\MaxEnvelopeSizeKb' -Value 8192 -Verbose

## Execute CIS Benchmark Report
Invoke-Expression "$PSScriptRoot\cisdsc.ps1"

## Archive Output Folder
Get-ChildItem -Path "$directory\Output" | Compress-Archive -DestinationPath "$directory\Output.zip"

## Revert the Envelope Size
Set-Item -Path 'WSMan:\localhost\MaxEnvelopeSizeKb' -Value $envelopeSize.value -Verbose

Write-Host "End of Execution"
Write-Host "Timestamp: $(Get-Date -Format "hh:mm:ss tt")"