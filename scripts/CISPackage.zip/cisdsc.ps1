﻿## CISDSC Scriptlet

Configuration Microsoft_Windows_Server_2016_Member_Server_1607_CIS_L1
{
    Import-DSCResource -ModuleName 'CISDSC' -Name 'CIS_Microsoft_Windows_Server_2016_Member_Server_Release_1607'

    node 'localhost'
    {
        CIS_Microsoft_Windows_Server_2016_Member_Server_Release_1607 'CIS Benchmarks'
        {
            #ExcludeList = @(
            #'2.3.7.5', # LegalNoticeText
            #'2.3.7.6', # LegalNoticeCaption
            #'5.6' # IIS Admin Service (IISADMIN)
            #)
            cis2315AccountsRenameadministratoraccount = 'CISAdmin'
            cis2316AccountsRenameguestaccount = 'CISGuest'
            cis2375LegalNoticeCaption = 'Legal Notice'
            cis2374LegalNoticeText = @"
This is a super secure device that we don't want bad people using.
I'm even making sure to put this as a literal string so that I can cleanly
use multiple lines to tell you how super secure it is.
"@
        }
    }
}

Microsoft_Windows_Server_2016_Member_Server_1607_CIS_L1

Configuration Microsoft_Windows_Server_2019_Member_Server_20H2_CIS_L1
{
    Import-DSCResource -ModuleName 'CISDSC' -Name 'CIS_Microsoft_Windows_Server_2019_Member_Server_Release_20H2'

    node 'localhost'
    {
        CIS_Microsoft_Windows_Server_2019_Member_Server_Release_20H2 'CIS Benchmarks'
        {
            cis2315AccountsRenameadministratoraccount = 'CISAdmin'
            cis2316AccountsRenameguestaccount = 'CISGuest'
            cis2375LegalNoticeCaption = 'Legal Notice'
            cis2374LegalNoticeText = @"
This is a super secure device that we don't want bad people using.
I'm even making sure to put this as a literal string so that I can cleanly
use multiple lines to tell you how super secure it is.
"@
        }
    }
}

Microsoft_Windows_Server_2019_Member_Server_20H2_CIS_L1

Configuration Microsoft_Windows_Server_2019_Member_Server_1809_CIS_L1
{
    Import-DSCResource -ModuleName 'CISDSC' -Name 'CIS_Microsoft_Windows_Server_2019_Member_Server_Release_1809'

    node 'localhost'
    {
        CIS_Microsoft_Windows_Server_2019_Member_Server_Release_1809 'CIS Benchmarks'
        {
            cis2315AccountsRenameadministratoraccount = 'CISAdmin'
            cis2316AccountsRenameguestaccount = 'CISGuest'
            cis2375LegalNoticeCaption = 'Legal Notice'
            cis2374LegalNoticeText = @"
This is a super secure device that we don't want bad people using.
I'm even making sure to put this as a literal string so that I can cleanly
use multiple lines to tell you how super secure it is.
"@
        }
    }
}

Microsoft_Windows_Server_2019_Member_Server_1809_CIS_L1

## Create Output Directory
If (not(Test-Path "$PSScriptRoot\Output")) {
    New-Item -Path "$PSScriptRoot\Output" -ItemType Directory
}

$Report = Test-DscConfiguration -Path ".\Microsoft_Windows_Server_2016_Member_Server_1607_CIS_L1" -Verbose
$Report.ResourcesInDesiredState | Select-Object -Property 'ResourceId','InDesiredState' | Export-CSV -Path "$PSScriptRoot\Output\ResourcesInDesiredState.csv"
$Report.ResourcesNotInDesiredState | Select-Object -Property 'ResourceId','InDesiredState' | Export-CSV -Path "$PSScriptRoot\Output\ResourcesNotInDesiredState.csv"